package com.dicoding.aplikasigithub.ui.activity

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.aplikasigithub.R
import com.dicoding.aplikasigithub.data.response.DetailUserResponse
import com.dicoding.aplikasigithub.databinding.ActivityDetailUserBinding
import com.dicoding.aplikasigithub.ui.Adapter.SectionPagerAdapter
import com.dicoding.aplikasigithub.ui.ViewModel.DetailViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailUserBinding
    private val detailViewModel by viewModels<DetailViewModel>()
    private var login: String? = null

    companion object {
        const val LOGIN = "login"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        login = intent.getStringExtra(LOGIN).toString()

        val noAction= supportActionBar
        noAction?.title="Show Detail - ${login}"

        val sectionsPagerAdapter = SectionPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.viewpager)
        viewPager.adapter = sectionsPagerAdapter
        sectionsPagerAdapter.username = login
        val tabs: TabLayout = findViewById(R.id.tabLayout)
        TabLayoutMediator(tabs, viewPager){ tab, position ->
            when(position){
                0 -> tab.text = resources.getString(R.string.followers)
                1 -> tab.text = resources.getString(R.string.following)
                else -> tab.text = "Nothing"
            }
        }.attach()
        supportActionBar?.elevation = 0f

        detailViewModel.getDetail(login!!)

        detailViewModel.detailResponse.observe(this) { show ->
            showDataDetail(show)
        }

        detailViewModel.isLoading.observe(this) { isLoading ->
            showLoading(isLoading)
        }
    }

    private fun showDataDetail(show: DetailUserResponse) {
        Glide.with(this)
            .load(show.avatarUrl)
            .into(binding.imgItemPhoto)
        binding.name.text = show.name
        binding.username.text = show.login
        binding.followers.text = "${show.followers} followers"
        binding.following.text = "${show.following} following"
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}