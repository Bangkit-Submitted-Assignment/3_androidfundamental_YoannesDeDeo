package com.dicoding.aplikasigithub.ui.activity

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.aplikasigithub.data.response.ItemsItem
import com.dicoding.aplikasigithub.databinding.ActivityMainBinding
import com.dicoding.aplikasigithub.ui.Adapter.RvAdapter
import com.dicoding.aplikasigithub.ui.ViewModel.MainViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()
    private lateinit var loadingProgressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        loadingProgressBar = binding.progressBar
        setContentView(binding.root)
        supportActionBar?.hide()

        mainViewModel.userResponse.observe(this) { userResponse ->
            val itemsItemList = userResponse?.items ?: emptyList()
            setReviewData(itemsItemList)
        }

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        mainViewModel.listReview.observe(this) { consumerReviews ->
            setReviewData(consumerReviews)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        eventClickItem()

    }
    private fun eventClickItem(){
        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { _, _, _ ->
                    searchBar.text = searchView.text
                    searchView.hide()
                    mainViewModel.resultSearch(searchBar.text.toString())
                    false
                }
        }
    }

    private fun setReviewData(consumerReviews: List<ItemsItem>) {
        val adapter = RvAdapter(this)
        adapter.submitList(consumerReviews)
        binding.rvUser.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    fun getLoadingProgressBar(): ProgressBar {
        return loadingProgressBar
    }

    override fun onResume() {
        super.onResume()
        showLoading(false)
    }
}